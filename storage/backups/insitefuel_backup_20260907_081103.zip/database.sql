--
-- PostgreSQL database dump
--

\restrict tNvDhyceE3lhLyjrdNi5EUzHRwSCa2yd34dAg6cFJa5sIVcgcLJHuFC5Aqj7Kk2

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    original_filename character varying(255) NOT NULL,
    stored_filename character varying(255) NOT NULL,
    storage_path character varying(500) NOT NULL,
    content_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    uploaded_by_user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.attachments OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO postgres;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    entity character varying(100) NOT NULL,
    entity_id integer,
    old_values jsonb,
    new_values jsonb,
    reason text,
    details text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: engine_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engine_events (
    id integer NOT NULL,
    equipment_id integer NOT NULL,
    engine_type character varying(100),
    start_time timestamp with time zone NOT NULL,
    stop_time timestamp with time zone,
    hours_run numeric(10,3),
    consumption numeric(12,3),
    lph_rate numeric(10,3),
    active boolean NOT NULL,
    remarks character varying(500),
    created_by_user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    shift_id integer NOT NULL
);


ALTER TABLE public.engine_events OWNER TO postgres;

--
-- Name: engine_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.engine_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.engine_events_id_seq OWNER TO postgres;

--
-- Name: engine_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.engine_events_id_seq OWNED BY public.engine_events.id;


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment (
    id integer NOT NULL,
    vessel_id integer NOT NULL,
    name character varying(150) NOT NULL,
    equipment_type character varying(100),
    code character varying(50),
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.equipment OWNER TO postgres;

--
-- Name: equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipment_id_seq OWNER TO postgres;

--
-- Name: equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipment_id_seq OWNED BY public.equipment.id;


--
-- Name: fuel_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fuel_transactions (
    id integer NOT NULL,
    shift_id integer NOT NULL,
    vessel_id integer NOT NULL,
    transaction_type character varying(30) NOT NULL,
    quantity numeric(12,3) NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    transaction_date timestamp with time zone NOT NULL,
    remarks character varying(500),
    created_by_user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    adjustment_direction character varying(10),
    source_vessel_id integer,
    fuel_source character varying(200),
    CONSTRAINT ck_fuel_transactions_quantity_positive CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.fuel_transactions OWNER TO postgres;

--
-- Name: fuel_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fuel_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fuel_transactions_id_seq OWNER TO postgres;

--
-- Name: fuel_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fuel_transactions_id_seq OWNED BY public.fuel_transactions.id;


--
-- Name: production_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_records (
    id integer NOT NULL,
    project_id integer NOT NULL,
    vessel_id integer NOT NULL,
    shift_id integer NOT NULL,
    production_date date NOT NULL,
    as_per_qty numeric(14,3) NOT NULL,
    true_qty numeric(14,3) NOT NULL,
    fuel_rate numeric(14,3),
    remarks character varying(500),
    created_by_user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.production_records OWNER TO postgres;

--
-- Name: production_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_records_id_seq OWNER TO postgres;

--
-- Name: production_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_records_id_seq OWNED BY public.production_records.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(50),
    description character varying(500),
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projects_id_seq OWNER TO postgres;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    user_id integer NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO postgres;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: shifts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shifts (
    id integer NOT NULL,
    vessel_id integer NOT NULL,
    shift_date date NOT NULL,
    shift_name character varying(50),
    opening_fuel numeric(12,3) NOT NULL,
    calculated_closing_fuel numeric(12,3),
    status character varying(30) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    closed_at timestamp with time zone
);


ALTER TABLE public.shifts OWNER TO postgres;

--
-- Name: shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shifts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shifts_id_seq OWNER TO postgres;

--
-- Name: shifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shifts_id_seq OWNED BY public.shifts.id;


--
-- Name: soundings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.soundings (
    id integer NOT NULL,
    vessel_id integer NOT NULL,
    report_date date NOT NULL,
    submitted_at timestamp with time zone NOT NULL,
    submitted_by_user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    attachment_id integer NOT NULL
);


ALTER TABLE public.soundings OWNER TO postgres;

--
-- Name: soundings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.soundings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.soundings_id_seq OWNER TO postgres;

--
-- Name: soundings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.soundings_id_seq OWNED BY public.soundings.id;


--
-- Name: transfers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transfers (
    id integer NOT NULL,
    from_vessel_id integer NOT NULL,
    to_vessel_id integer NOT NULL,
    initiated_quantity numeric(12,3) NOT NULL,
    received_quantity numeric(12,3),
    loss_quantity numeric(12,3),
    status character varying(30) NOT NULL,
    transfer_date timestamp with time zone NOT NULL,
    initiated_by_user_id integer NOT NULL,
    received_by_user_id integer,
    reviewed_by_user_id integer,
    approved_by_user_id integer,
    initiated_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone,
    reviewed_at timestamp with time zone,
    approved_at timestamp with time zone,
    manager_remark character varying(1000),
    notes character varying(1000),
    created_at timestamp with time zone NOT NULL,
    from_shift_id integer NOT NULL,
    to_shift_id integer NOT NULL,
    CONSTRAINT ck_transfers_different_vessels CHECK ((from_vessel_id <> to_vessel_id)),
    CONSTRAINT ck_transfers_initiated_quantity_positive CHECK ((initiated_quantity > (0)::numeric)),
    CONSTRAINT ck_transfers_loss_quantity_nonnegative CHECK (((loss_quantity IS NULL) OR (loss_quantity >= (0)::numeric))),
    CONSTRAINT ck_transfers_received_quantity_nonnegative CHECK (((received_quantity IS NULL) OR (received_quantity >= (0)::numeric)))
);


ALTER TABLE public.transfers OWNER TO postgres;

--
-- Name: transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transfers_id_seq OWNER TO postgres;

--
-- Name: transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transfers_id_seq OWNED BY public.transfers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(30) NOT NULL,
    full_name character varying(150),
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_users_role_valid CHECK (((role)::text = ANY ((ARRAY['ADMIN'::character varying, 'MANAGER'::character varying, 'OPERATOR'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vessels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vessels (
    id integer NOT NULL,
    project_id integer NOT NULL,
    name character varying(150) NOT NULL,
    code character varying(50),
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    fuel_threshold_litres numeric(12,3) NOT NULL
);


ALTER TABLE public.vessels OWNER TO postgres;

--
-- Name: vessels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vessels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vessels_id_seq OWNER TO postgres;

--
-- Name: vessels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vessels_id_seq OWNED BY public.vessels.id;


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: engine_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_events ALTER COLUMN id SET DEFAULT nextval('public.engine_events_id_seq'::regclass);


--
-- Name: equipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment ALTER COLUMN id SET DEFAULT nextval('public.equipment_id_seq'::regclass);


--
-- Name: fuel_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_transactions ALTER COLUMN id SET DEFAULT nextval('public.fuel_transactions_id_seq'::regclass);


--
-- Name: production_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_records ALTER COLUMN id SET DEFAULT nextval('public.production_records_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: shifts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts ALTER COLUMN id SET DEFAULT nextval('public.shifts_id_seq'::regclass);


--
-- Name: soundings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soundings ALTER COLUMN id SET DEFAULT nextval('public.soundings_id_seq'::regclass);


--
-- Name: transfers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers ALTER COLUMN id SET DEFAULT nextval('public.transfers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vessels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vessels ALTER COLUMN id SET DEFAULT nextval('public.vessels_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
898db80ad781
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachments (id, original_filename, stored_filename, storage_path, content_type, file_size, uploaded_by_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, user_id, action, entity, entity_id, old_values, new_values, reason, details, created_at) FROM stdin;
\.


--
-- Data for Name: engine_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.engine_events (id, equipment_id, engine_type, start_time, stop_time, hours_run, consumption, lph_rate, active, remarks, created_by_user_id, created_at, shift_id) FROM stdin;
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment (id, vessel_id, name, equipment_type, code, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: fuel_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fuel_transactions (id, shift_id, vessel_id, transaction_type, quantity, reference_type, reference_id, transaction_date, remarks, created_by_user_id, created_at, adjustment_direction, source_vessel_id, fuel_source) FROM stdin;
\.


--
-- Data for Name: production_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_records (id, project_id, vessel_id, shift_id, production_date, as_per_qty, true_qty, fuel_rate, remarks, created_by_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, name, code, description, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, session_token, user_id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shifts (id, vessel_id, shift_date, shift_name, opening_fuel, calculated_closing_fuel, status, created_at, closed_at) FROM stdin;
\.


--
-- Data for Name: soundings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.soundings (id, vessel_id, report_date, submitted_at, submitted_by_user_id, created_at, attachment_id) FROM stdin;
\.


--
-- Data for Name: transfers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transfers (id, from_vessel_id, to_vessel_id, initiated_quantity, received_quantity, loss_quantity, status, transfer_date, initiated_by_user_id, received_by_user_id, reviewed_by_user_id, approved_by_user_id, initiated_at, received_at, reviewed_at, approved_at, manager_remark, notes, created_at, from_shift_id, to_shift_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password_hash, role, full_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vessels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vessels (id, project_id, name, code, is_active, created_at, fuel_threshold_litres) FROM stdin;
\.


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: engine_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.engine_events_id_seq', 1, false);


--
-- Name: equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipment_id_seq', 1, false);


--
-- Name: fuel_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fuel_transactions_id_seq', 1, false);


--
-- Name: production_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_records_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: shifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shifts_id_seq', 1, false);


--
-- Name: soundings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.soundings_id_seq', 1, false);


--
-- Name: transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transfers_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: vessels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vessels_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_stored_filename_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_stored_filename_key UNIQUE (stored_filename);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: engine_events engine_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_events
    ADD CONSTRAINT engine_events_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: fuel_transactions fuel_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_pkey PRIMARY KEY (id);


--
-- Name: production_records production_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_records
    ADD CONSTRAINT production_records_pkey PRIMARY KEY (id);


--
-- Name: projects projects_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_code_key UNIQUE (code);


--
-- Name: projects projects_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_name_key UNIQUE (name);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: soundings soundings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soundings
    ADD CONSTRAINT soundings_pkey PRIMARY KEY (id);


--
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: shifts uq_shifts_vessel_date_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT uq_shifts_vessel_date_name UNIQUE (vessel_id, shift_date, shift_name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vessels vessels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vessels
    ADD CONSTRAINT vessels_pkey PRIMARY KEY (id);


--
-- Name: ix_attachments_uploaded_by_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attachments_uploaded_by_user_id ON public.attachments USING btree (uploaded_by_user_id);


--
-- Name: ix_audit_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: ix_audit_log_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_created_at ON public.audit_log USING btree (created_at);


--
-- Name: ix_audit_log_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_entity ON public.audit_log USING btree (entity);


--
-- Name: ix_audit_log_entity_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_entity_id ON public.audit_log USING btree (entity_id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_engine_events_created_by_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_engine_events_created_by_user_id ON public.engine_events USING btree (created_by_user_id);


--
-- Name: ix_engine_events_equipment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_engine_events_equipment_id ON public.engine_events USING btree (equipment_id);


--
-- Name: ix_engine_events_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_engine_events_shift_id ON public.engine_events USING btree (shift_id);


--
-- Name: ix_equipment_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_equipment_vessel_id ON public.equipment USING btree (vessel_id);


--
-- Name: ix_fuel_transactions_created_by_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_fuel_transactions_created_by_user_id ON public.fuel_transactions USING btree (created_by_user_id);


--
-- Name: ix_fuel_transactions_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_fuel_transactions_shift_id ON public.fuel_transactions USING btree (shift_id);


--
-- Name: ix_fuel_transactions_source_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_fuel_transactions_source_vessel_id ON public.fuel_transactions USING btree (source_vessel_id);


--
-- Name: ix_fuel_transactions_transaction_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_fuel_transactions_transaction_date ON public.fuel_transactions USING btree (transaction_date);


--
-- Name: ix_fuel_transactions_transaction_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_fuel_transactions_transaction_type ON public.fuel_transactions USING btree (transaction_type);


--
-- Name: ix_fuel_transactions_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_fuel_transactions_vessel_id ON public.fuel_transactions USING btree (vessel_id);


--
-- Name: ix_production_records_created_by_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_production_records_created_by_user_id ON public.production_records USING btree (created_by_user_id);


--
-- Name: ix_production_records_production_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_production_records_production_date ON public.production_records USING btree (production_date);


--
-- Name: ix_production_records_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_production_records_project_id ON public.production_records USING btree (project_id);


--
-- Name: ix_production_records_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_production_records_shift_id ON public.production_records USING btree (shift_id);


--
-- Name: ix_production_records_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_production_records_vessel_id ON public.production_records USING btree (vessel_id);


--
-- Name: ix_sessions_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_sessions_expires_at ON public.sessions USING btree (expires_at);


--
-- Name: ix_sessions_session_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_sessions_session_token ON public.sessions USING btree (session_token);


--
-- Name: ix_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_sessions_user_id ON public.sessions USING btree (user_id);


--
-- Name: ix_shifts_shift_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_shifts_shift_date ON public.shifts USING btree (shift_date);


--
-- Name: ix_shifts_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_shifts_vessel_id ON public.shifts USING btree (vessel_id);


--
-- Name: ix_soundings_attachment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_soundings_attachment_id ON public.soundings USING btree (attachment_id);


--
-- Name: ix_soundings_report_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_soundings_report_date ON public.soundings USING btree (report_date);


--
-- Name: ix_soundings_submitted_by_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_soundings_submitted_by_user_id ON public.soundings USING btree (submitted_by_user_id);


--
-- Name: ix_soundings_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_soundings_vessel_id ON public.soundings USING btree (vessel_id);


--
-- Name: ix_transfers_from_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transfers_from_shift_id ON public.transfers USING btree (from_shift_id);


--
-- Name: ix_transfers_from_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transfers_from_vessel_id ON public.transfers USING btree (from_vessel_id);


--
-- Name: ix_transfers_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transfers_status ON public.transfers USING btree (status);


--
-- Name: ix_transfers_to_shift_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transfers_to_shift_id ON public.transfers USING btree (to_shift_id);


--
-- Name: ix_transfers_to_vessel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transfers_to_vessel_id ON public.transfers USING btree (to_vessel_id);


--
-- Name: ix_transfers_transfer_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transfers_transfer_date ON public.transfers USING btree (transfer_date);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_vessels_project_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_vessels_project_id ON public.vessels USING btree (project_id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: engine_events engine_events_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_events
    ADD CONSTRAINT engine_events_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: engine_events engine_events_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_events
    ADD CONSTRAINT engine_events_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment(id);


--
-- Name: engine_events engine_events_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engine_events
    ADD CONSTRAINT engine_events_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: equipment equipment_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_vessel_id_fkey FOREIGN KEY (vessel_id) REFERENCES public.vessels(id);


--
-- Name: soundings fk_soundings_attachment_id_attachments; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soundings
    ADD CONSTRAINT fk_soundings_attachment_id_attachments FOREIGN KEY (attachment_id) REFERENCES public.attachments(id);


--
-- Name: fuel_transactions fuel_transactions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: fuel_transactions fuel_transactions_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: fuel_transactions fuel_transactions_source_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_source_vessel_id_fkey FOREIGN KEY (source_vessel_id) REFERENCES public.vessels(id);


--
-- Name: fuel_transactions fuel_transactions_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_transactions
    ADD CONSTRAINT fuel_transactions_vessel_id_fkey FOREIGN KEY (vessel_id) REFERENCES public.vessels(id);


--
-- Name: production_records production_records_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_records
    ADD CONSTRAINT production_records_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: production_records production_records_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_records
    ADD CONSTRAINT production_records_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: production_records production_records_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_records
    ADD CONSTRAINT production_records_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: production_records production_records_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_records
    ADD CONSTRAINT production_records_vessel_id_fkey FOREIGN KEY (vessel_id) REFERENCES public.vessels(id);


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shifts shifts_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_vessel_id_fkey FOREIGN KEY (vessel_id) REFERENCES public.vessels(id);


--
-- Name: soundings soundings_submitted_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soundings
    ADD CONSTRAINT soundings_submitted_by_user_id_fkey FOREIGN KEY (submitted_by_user_id) REFERENCES public.users(id);


--
-- Name: soundings soundings_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.soundings
    ADD CONSTRAINT soundings_vessel_id_fkey FOREIGN KEY (vessel_id) REFERENCES public.vessels(id);


--
-- Name: transfers transfers_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id);


--
-- Name: transfers transfers_from_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_from_shift_id_fkey FOREIGN KEY (from_shift_id) REFERENCES public.shifts(id);


--
-- Name: transfers transfers_from_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_from_vessel_id_fkey FOREIGN KEY (from_vessel_id) REFERENCES public.vessels(id);


--
-- Name: transfers transfers_initiated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_initiated_by_user_id_fkey FOREIGN KEY (initiated_by_user_id) REFERENCES public.users(id);


--
-- Name: transfers transfers_received_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_received_by_user_id_fkey FOREIGN KEY (received_by_user_id) REFERENCES public.users(id);


--
-- Name: transfers transfers_reviewed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_reviewed_by_user_id_fkey FOREIGN KEY (reviewed_by_user_id) REFERENCES public.users(id);


--
-- Name: transfers transfers_to_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_to_shift_id_fkey FOREIGN KEY (to_shift_id) REFERENCES public.shifts(id);


--
-- Name: transfers transfers_to_vessel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_to_vessel_id_fkey FOREIGN KEY (to_vessel_id) REFERENCES public.vessels(id);


--
-- Name: vessels vessels_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vessels
    ADD CONSTRAINT vessels_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- PostgreSQL database dump complete
--

\unrestrict tNvDhyceE3lhLyjrdNi5EUzHRwSCa2yd34dAg6cFJa5sIVcgcLJHuFC5Aqj7Kk2

